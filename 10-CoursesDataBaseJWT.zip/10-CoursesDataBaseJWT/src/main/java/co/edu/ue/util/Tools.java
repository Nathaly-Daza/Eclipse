package co.edu.ue.util;

public class Tools {
	public static final String CLAVE="123333333333333aaaaaaaaa900000000";
	
	public static final String ENCABEZADO ="Authorization";
	public static final String PREFIJO_TOKEN ="Bearer ";
}
